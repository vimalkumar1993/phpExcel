<?php
session_start();
ob_start();
error_reporting(E_ALL ^ E_NOTICE);
require_once 'excel_reader.php';
require_once 'connection.php';
$data = new Spreadsheet_Excel_Reader("example.xls");
?>
<html>
<head>
</head>

<body>
<!--Value(val,val)
rowcount() -->
<?php 
//echo $data->colcount()."<br>";
//echo $data->rowcount()."<br>";

$testid=$_GET['courseid'];
$subtopic=$_GET['subtopic'];
$subtopicid=$_GET['subtopicid'];
$courseid=$_GET['courseid'];
    
$error=0;    
$question=array();
$optA=array();
$optB=array();
$optC=array();
$optD=array();
$optE=array();
$answer=array();
$solution=array();
for($row=2;$row<=$data->rowcount();$row++) {
	for($col=1;$col<=$data->colcount();$col++) {
            if($col==1) {
                $question[$row]=trim($data->value($row,$col));   
            } else if($col==2) {
                $subQuestion[$row]=$data->value($row,$col);   
            } else if($col==3) {
                $optA[$row]=$data->value($row,$col);   
            } else if($col==4) {
                $optB[$row]=$data->value($row,$col);   
            } else if($col==5) {
                $optC[$row]=$data->value($row,$col);   
            } else if($col==6) {
                $optD[$row]=$data->value($row,$col);   
            } else if($col==7) {
                $optE[$row]=$data->value($row,$col);   
            } else if($col==8) {
                $answer[$row]=$data->value($row,$col);   
            } else if($col==9) {
                $solution[$row]=trim($data->value($row,$col));   
            }
	}
}

    for($i=2;$i<sizeof($question)+2;$i++) {
        $query=$con->query("insert into questions(question,sub_question,answer1,answer2,answer3,answer4,answer5,answer,solution) values('$question[$i]','$subQuestion[$i]','$optA[$i]','$optB[$i]','$optC[$i]','$optD[$i]','$optE[$i]','$answer[$i]','$solution[$i]')");
    }
    if($query) {
            echo "Your questions inserted successfully!";
    } else {
            echo "Erro inserting : ".$con->error;
    }

?>
</body>
</html>
