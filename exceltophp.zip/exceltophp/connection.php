<?php
    $con=new mysqli("localhost","root","","excel");
    //$db=mysqli_select_db("excel");
    if ($con->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    } 
?>